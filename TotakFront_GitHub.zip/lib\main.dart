import 'package:flutter/material.dart';

void main() => runApp(const TotakApp());

class TotakApp extends StatelessWidget {
  const TotakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Totak',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFFFF3F8),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF5A68)),
      ),
      home: const LocalWelcomePage(),
    );
  }
}

class LocalWelcomePage extends StatefulWidget {
  const LocalWelcomePage({super.key});

  @override
  State<LocalWelcomePage> createState() => _LocalWelcomePageState();
}

class _LocalWelcomePageState extends State<LocalWelcomePage> {
  final nameController = TextEditingController();

  @override
  void dispose() {
    nameController.dispose();
    super.dispose();
  }

  void start() {
    final name = nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Please enter your name.')));
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => ShortsPage(viewerName: name)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const _WelcomeBackdrop(),
          const _LoginWarmOverlay(),
          SafeArea(
            child: Align(
              alignment: const Alignment(0, 0.72),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 24, 24, 28),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF0E4).withValues(alpha: 0.92),
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(
                        color: const Color(0xFFFFB36B),
                        width: 1.2,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x550E0822),
                          blurRadius: 24,
                          offset: Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Enter your name to continue',
                            textDirection: TextDirection.ltr,
                            style: TextStyle(
                              color: Color(0xFF7D1739),
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: nameController,
                          textInputAction: TextInputAction.done,
                          onSubmitted: (_) => start(),
                          style: const TextStyle(
                            color: Color(0xFF5C1C32),
                            fontSize: 16,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Name',
                            hintStyle: TextStyle(
                              color: const Color(0xFF5C1C32)
                                  .withValues(alpha: 0.48),
                            ),
                            prefixIcon: const Icon(
                              Icons.person_outline_rounded,
                              color: Color(0xFFE84D57),
                            ),
                            filled: true,
                            fillColor: const Color(0xFFFFDFC3),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(18),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(18),
                              borderSide: const BorderSide(
                                color: Color(0xFFFF8A4D),
                                width: 1.5,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: FilledButton(
                            onPressed: start,
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFE84D57),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18),
                              ),
                              textStyle: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            child: const Text('Start'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WelcomeBackdrop extends StatelessWidget {
  const _WelcomeBackdrop();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox.expand(
        child: Image.asset(
          'assets/images/welcome_background.png',
          fit: BoxFit.cover,
          alignment: Alignment.center,
        ),
      ),
    );
  }
}

class _LoginWarmOverlay extends StatelessWidget {
  const _LoginWarmOverlay();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFFFF8A67).withValues(alpha: 0.18),
              const Color(0xFFFFC16B).withValues(alpha: 0.14),
              const Color(0xFFE84D57).withValues(alpha: 0.16),
            ],
          ),
        ),
      ),
    );
  }
}

class _TotakBrand extends StatelessWidget {
  const _TotakBrand({this.logoSize = 34, this.textSize = 17});

  final double logoSize;
  final double textSize;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(
          'assets/images/logo.png',
          width: logoSize,
          height: logoSize,
        ),
        const SizedBox(height: 1),
        Text(
          'Totak',
          style: TextStyle(
            color: const Color(0xFFFFF0E3),
            fontSize: textSize,
            fontWeight: FontWeight.w900,
            fontFamily: 'Comic Sans MS',
            letterSpacing: 0.4,
            height: 0.95,
          ),
        ),
      ],
    );
  }
}

class ShortsPage extends StatefulWidget {
  const ShortsPage({super.key, required this.viewerName});

  final String viewerName;

  @override
  State<ShortsPage> createState() => _ShortsPageState();
}

class _ShortsPageState extends State<ShortsPage> {
  bool isPlaying = true;
  int currentClip = 0;

  final clips = const [
    {
      'title': 'Color in Motion',
      'category': 'Art',
      'duration': '00:18',
      'accent': Color(0xFFFF725E),
    },
    {
      'title': 'Little Sky',
      'category': 'Mood',
      'duration': '00:24',
      'accent': Color(0xFFFFA15E),
    },
    {
      'title': 'Make It Happen',
      'category': 'Energy',
      'duration': '00:16',
      'accent': Color(0xFFFF9A5C),
    },
    {
      'title': 'Pink Horizon',
      'category': 'Glow',
      'duration': '00:21',
      'accent': Color(0xFFFF628D),
    },
    {
      'title': 'Soft Focus',
      'category': 'Mood',
      'duration': '00:14',
      'accent': Color(0xFFFF7C6D),
    },
    {
      'title': 'Good Energy',
      'category': 'Energy',
      'duration': '00:19',
      'accent': Color(0xFFFFA45C),
    },
    {
      'title': 'Dream Sequence',
      'category': 'Art',
      'duration': '00:26',
      'accent': Color(0xFFFF7D83),
    },
    {
      'title': 'Afterglow',
      'category': 'Glow',
      'duration': '00:17',
      'accent': Color(0xFFFF9C70),
    },
    {
      'title': 'Bright Side',
      'category': 'Energy',
      'duration': '00:22',
      'accent': Color(0xFFFF876D),
    },
  ];

  void openClip(int index) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ShortClipViewer(
          clip: clips[index],
          clipIndex: index,
          totalClips: clips.length,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Scaffold(
        backgroundColor: const Color(0xFF8B183B),
        body: Stack(
          fit: StackFit.expand,
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF8C173A),
                    Color(0xFFD6364E),
                    Color(0xFFFF7A57),
                    Color(0xFFFFB65E),
                  ],
                  stops: [0, 0.35, 0.72, 1],
                ),
              ),
            ),
            Container(color: const Color(0xFFFF7B55).withValues(alpha: 0.18)),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                        const Spacer(),
                        const _TotakBrand(logoSize: 31, textSize: 17),
                        const Spacer(),
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(
                            Icons.tune_rounded,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(10, 4, 10, 14),
                      itemCount: clips.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            crossAxisSpacing: 6,
                            mainAxisSpacing: 6,
                            childAspectRatio: 0.72,
                          ),
                      itemBuilder: (context, index) {
                        final clip = clips[index];
                        return _ShortGridTile(
                          clip: clip,
                          onTap: () => openClip(index),
                        );
                      },
                    ),
                  ),
                  TotakBottomNav(
                    currentIndex: 2,
                    viewerName: widget.viewerName,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShortGridTile extends StatelessWidget {
  const _ShortGridTile({required this.clip, required this.onTap});

  final Map<String, Object> clip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = clip['accent']! as Color;
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(
              'assets/images/welcome_background.png',
              fit: BoxFit.cover,
              alignment: Alignment.topCenter,
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    accent.withValues(alpha: 0.68),
                    const Color(0xFFE84D57).withValues(alpha: 0.38),
                    const Color(0xFF7D1739).withValues(alpha: 0.86),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 9),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.22),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: Text(
                        clip['duration']! as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        clip['category']! as String,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.82),
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        clip['title']! as String,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          height: 1.05,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MiniGamesPage extends StatefulWidget {
  const MiniGamesPage({super.key, required this.viewerName});

  final String viewerName;

  @override
  State<MiniGamesPage> createState() => _MiniGamesPageState();
}

class _MiniGamesPageState extends State<MiniGamesPage> {
  int selectedGame = 0;
  int localScore = 1260;

  final games = const [
    {
      'title': 'Bubble Pop',
      'subtitle': 'Tap fast',
      'icon': Icons.bubble_chart_rounded,
      'accent': Color(0xFFFF5964),
      'soft': Color(0xFFFF887A),
    },
    {
      'title': 'Memory Flip',
      'subtitle': 'Match pairs',
      'icon': Icons.style_rounded,
      'accent': Color(0xFFFF9B52),
      'soft': Color(0xFFFFC275),
    },
    {
      'title': 'Color Rush',
      'subtitle': 'React quicker',
      'icon': Icons.bolt_rounded,
      'accent': Color(0xFFFF3F68),
      'soft': Color(0xFFFF7584),
    },
    {
      'title': 'Puzzle Pop',
      'subtitle': 'Build the picture',
      'icon': Icons.extension_rounded,
      'accent': Color(0xFFFF7B4E),
      'soft': Color(0xFFFFB86C),
    },
  ];

  void playSelected() {
    setState(() => localScore += 25);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${games[selectedGame]['title']} started'),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF4C1C55),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Scaffold(
        backgroundColor: const Color(0xFF6A1233),
        body: Stack(
          fit: StackFit.expand,
          children: [
            const _WarmPaletteBackground(),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 12, 6),
                    child: Row(
                      children: [
                        const SizedBox(width: 48),
                        const Spacer(),
                        const _TotakBrand(logoSize: 42, textSize: 18),
                        const Spacer(),
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(
                            Icons.settings_rounded,
                            color: Color(0xFFFFF2DF),
                            size: 27,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 8, 18, 14),
                      children: [
                        GestureDetector(
                          onTap: () => ScaffoldMessenger.of(context)
                              .showSnackBar(
                                const SnackBar(
                                  content: Text('Leaderboard is coming next'),
                                  behavior: SnackBarBehavior.floating,
                                ),
                              ),
                          child: Container(
                            height: 68,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            margin: const EdgeInsets.only(bottom: 13),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  Color(0xFF9D1C45),
                                  Color(0xFFEF4E5F),
                                  Color(0xFFFF9B52),
                                ],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(23),
                              border: Border.all(
                                color: const Color(0xFFFFC99E)
                                    .withValues(alpha: 0.55),
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x55000000),
                                  blurRadius: 18,
                                  offset: Offset(0, 9),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.emoji_events_rounded,
                                  color: Color(0xFFFFD77D),
                                  size: 30,
                                ),
                                const SizedBox(width: 9),
                                Text(
                                  '$localScore',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 28,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  'POINTS',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.78),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.1,
                                  ),
                                ),
                                const Spacer(),
                                Container(
                                  width: 50,
                                  height: 38,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withValues(alpha: 0.18),
                                    borderRadius: BorderRadius.circular(13),
                                  ),
                                  child: const Icon(
                                    Icons.leaderboard_rounded,
                                    color: Colors.white,
                                    size: 24,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          height: 272,
                          decoration: BoxDecoration(
                            color: const Color(0xFF8C2144),
                            borderRadius: BorderRadius.circular(26),
                            border: Border.all(
                              color: const Color(0xFFFFBB96)
                                  .withValues(alpha: 0.6),
                            ),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x50000000),
                                blurRadius: 19,
                                offset: Offset(0, 9),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(26),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Image.asset(
                                  'assets/images/mini_game_hero.png',
                                  fit: BoxFit.cover,
                                  alignment: Alignment.center,
                                ),
                                DecoratedBox(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        const Color(0xFF67112F)
                                            .withValues(alpha: 0.9),
                                      ],
                                      stops: const [0.38, 1],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  left: 17,
                                  right: 17,
                                  bottom: 15,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      const Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'SPACE BERRY',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 21,
                                                fontWeight: FontWeight.w900,
                                                letterSpacing: 0.2,
                                              ),
                                            ),
                                            SizedBox(height: 3),
                                            Text(
                                              'Arcade  ·  New high score',
                                              style: TextStyle(
                                                color: Color(0xFFFFD7C0),
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      FilledButton.icon(
                                        onPressed: playSelected,
                                        icon: const Icon(
                                          Icons.play_arrow_rounded,
                                          size: 21,
                                        ),
                                        label: const Text('Play'),
                                        style: FilledButton.styleFrom(
                                          backgroundColor: const Color(
                                            0xFFFFAB3D,
                                          ),
                                          foregroundColor: const Color(
                                            0xFF6A1233,
                                          ),
                                          minimumSize: const Size(108, 47),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              17,
                                            ),
                                          ),
                                          textStyle: const TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 15,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text(
                              'Mini Games',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            Text(
                              '${games.length} games',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.68),
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: games.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 11,
                                mainAxisSpacing: 11,
                                childAspectRatio: 0.9,
                              ),
                          itemBuilder: (context, index) {
                            final game = games[index];
                            final active = index == selectedGame;
                            return _MiniGameCard(
                              game: game,
                              active: active,
                              onTap: () => setState(() => selectedGame = index),
                            );
                          },
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          height: 51,
                          child: OutlinedButton.icon(
                            onPressed: () => ScaffoldMessenger.of(context)
                                .showSnackBar(
                                  const SnackBar(
                                    content: Text('Leaderboard is coming next'),
                                    behavior: SnackBarBehavior.floating,
                                  ),
                                ),
                            icon: const Icon(
                              Icons.leaderboard_rounded,
                              size: 20,
                            ),
                            label: const Text('Leaderboard'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: BorderSide(
                                color: const Color(0xFFFFC99E)
                                    .withValues(alpha: 0.7),
                                width: 1.2,
                              ),
                              backgroundColor: const Color(0xFF8F2043)
                                  .withValues(alpha: 0.8),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(17),
                              ),
                              textStyle: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  TotakBottomNav(
                    currentIndex: 1,
                    viewerName: widget.viewerName,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniGameCard extends StatelessWidget {
  const _MiniGameCard({
    required this.game,
    required this.active,
    required this.onTap,
  });

  final Map<String, Object> game;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final accent = game['accent']! as Color;
    final soft = game['soft']! as Color;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [accent, soft, const Color(0xFF7D1739)],
            stops: const [0, 0.48, 1],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: active
                ? const Color(0xFFFFE1BF)
                : Colors.white.withValues(alpha: 0.22),
            width: active ? 2.2 : 1,
          ),
          boxShadow: active
              ? [
                  BoxShadow(
                    color: accent.withValues(alpha: 0.45),
                    blurRadius: 17,
                    offset: const Offset(0, 8),
                  ),
                ]
              : [],
        ),
        child: Stack(
          children: [
            Positioned(
              top: -12,
              right: -9,
              child: Icon(
                Icons.auto_awesome_rounded,
                size: 64,
                color: Colors.white.withValues(alpha: 0.16),
              ),
            ),
            Positioned(
              bottom: 17,
              left: 16,
              child: Icon(
                Icons.auto_awesome_rounded,
                size: 22,
                color: Colors.white.withValues(alpha: 0.3),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 13, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Icon(
                      game['icon']! as IconData,
                      color: Colors.white,
                      size: 35,
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        game['title']! as String,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        game['subtitle']! as String,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.78),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WarmPaletteBackground extends StatelessWidget {
  const _WarmPaletteBackground();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF7D1739),
              Color(0xFFC52C4A),
              Color(0xFFFF7B65),
              Color(0xFFFFB35F),
            ],
            stops: [0, 0.36, 0.72, 1],
          ),
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key, required this.viewerName});

  final String viewerName;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Scaffold(
        backgroundColor: const Color(0xFF7D1739),
        body: Stack(
          fit: StackFit.expand,
          children: [
            const _WarmPaletteBackground(),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 12, 6),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: Color(0xFFFFF2DF),
                            size: 21,
                          ),
                        ),
                        const Spacer(),
                        const _TotakBrand(logoSize: 38, textSize: 17),
                        const Spacer(),
                        IconButton(
                          onPressed: () => ScaffoldMessenger.of(context)
                              .showSnackBar(
                                const SnackBar(
                                  content: Text('Settings are coming next'),
                                  behavior: SnackBarBehavior.floating,
                                ),
                              ),
                          icon: const Icon(
                            Icons.settings_rounded,
                            color: Color(0xFFFFF2DF),
                            size: 26,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
                      children: [
                        Container(
                          padding: const EdgeInsets.fromLTRB(18, 20, 18, 18),
                          decoration: BoxDecoration(
                            color: const Color(0xFF8A1D3F)
                                .withValues(alpha: 0.9),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: const Color(0xFFFFC99E)
                                  .withValues(alpha: 0.6),
                            ),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x55000000),
                                blurRadius: 18,
                                offset: Offset(0, 9),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Container(
                                width: 92,
                                height: 92,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xFFFFD26D),
                                      Color(0xFFFF6A67),
                                    ],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  border: Border.all(
                                    color: const Color(0xFFFFF0D5),
                                    width: 4,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Color(0x55000000),
                                      blurRadius: 14,
                                      offset: Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.person_rounded,
                                  color: Color(0xFF7D1739),
                                  size: 53,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                viewerName,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 25,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'GUEST PLAYER',
                                style: TextStyle(
                                  color: Colors.white.withValues(alpha: 0.72),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                ),
                              ),
                              const SizedBox(height: 17),
                              Row(
                                children: [
                                  Expanded(
                                    child: _ProfileMetric(
                                      value: '1,260',
                                      label: 'Points',
                                      icon: Icons.star_rounded,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _ProfileMetric(
                                      value: '08',
                                      label: 'Best streak',
                                      icon: Icons.local_fire_department_rounded,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _ProfileMetric(
                                      value: '12',
                                      label: 'Games',
                                      icon: Icons.sports_esports_rounded,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          'Your progress',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.all(17),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFE0C7)
                                .withValues(alpha: 0.95),
                            borderRadius: BorderRadius.circular(23),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Level 04',
                                    style: TextStyle(
                                      color: Color(0xFF7D1739),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  Text(
                                    '72%',
                                    style: TextStyle(
                                      color: const Color(0xFF7D1739)
                                          .withValues(alpha: 0.7),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: const LinearProgressIndicator(
                                  value: 0.72,
                                  minHeight: 9,
                                  backgroundColor: Color(0xFFFFB5A1),
                                  valueColor: AlwaysStoppedAnimation(
                                    Color(0xFFE83D58),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 9),
                              Text(
                                '240 points to the next level',
                                style: TextStyle(
                                  color: const Color(0xFF7D1739)
                                      .withValues(alpha: 0.72),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          'Quick access',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        _ProfileAction(
                          icon: Icons.emoji_events_rounded,
                          title: 'Leaderboard',
                          subtitle: 'See your local ranking',
                          onTap: () {},
                        ),
                        const SizedBox(height: 10),
                        _ProfileAction(
                          icon: Icons.history_rounded,
                          title: 'Game history',
                          subtitle: 'Your recent plays',
                          onTap: () {},
                        ),
                        const SizedBox(height: 10),
                        _ProfileAction(
                          icon: Icons.tune_rounded,
                          title: 'Settings',
                          subtitle: 'Sound, theme and storage',
                          onTap: () {},
                        ),
                      ],
                    ),
                  ),
                  TotakBottomNav(currentIndex: 0, viewerName: viewerName),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileMetric extends StatelessWidget {
  const _ProfileMetric({
    required this.value,
    required this.label,
    required this.icon,
  });

  final String value;
  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 7),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(17),
      ),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFFFD77D), size: 20),
          const SizedBox(height: 3),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.7),
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileAction extends StatelessWidget {
  const _ProfileAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF8A1D3F).withValues(alpha: 0.86),
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF9B52).withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: const Color(0xFFFFD77D), size: 25),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.68),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                color: Colors.white.withValues(alpha: 0.65),
                size: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShortClipViewer extends StatefulWidget {
  const ShortClipViewer({
    super.key,
    required this.clip,
    required this.clipIndex,
    required this.totalClips,
  });

  final Map<String, Object> clip;
  final int clipIndex;
  final int totalClips;

  @override
  State<ShortClipViewer> createState() => _ShortClipViewerState();
}

class _ShortClipViewerState extends State<ShortClipViewer> {
  bool isPlaying = true;

  @override
  Widget build(BuildContext context) {
    final accent = widget.clip['accent']! as Color;
    return Scaffold(
      backgroundColor: const Color(0xFF7D1739),
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => isPlaying = !isPlaying),
        child: Stack(
          fit: StackFit.expand,
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF8C173A),
                    Color(0xFFE84D57),
                    Color(0xFFFF7A57),
                    Color(0xFFFFB65E),
                  ],
                ),
              ),
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFFFF9A5C).withValues(alpha: 0.08),
                    const Color(0xFF7D1739).withValues(alpha: 0.9),
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: Colors.white,
                            size: 23,
                          ),
                        ),
                        const Spacer(),
                        const _TotakBrand(logoSize: 33, textSize: 17),
                        const Spacer(),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.clip['category']! as String,
                          style: TextStyle(
                            color: accent,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.clip['title']! as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 18),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: LinearProgressIndicator(
                            value: isPlaying ? 0.48 : 0.2,
                            minHeight: 5,
                            backgroundColor: Colors.white.withValues(
                              alpha: 0.2,
                            ),
                            valueColor: AlwaysStoppedAnimation(accent),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              isPlaying ? 'Playing' : 'Paused',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.72),
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              '${widget.clipIndex + 1}/${widget.totalClips}',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.72),
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (!isPlaying)
              Center(
                child: IgnorePointer(
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.play_arrow_rounded,
                      color: Colors.white,
                      size: 38,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class TotakBottomNav extends StatelessWidget {
  const TotakBottomNav({
    super.key,
    required this.currentIndex,
    required this.viewerName,
  });

  final int currentIndex;
  final String viewerName;

  void _goTo(BuildContext context, int index) {
    if (index == currentIndex) return;
    if (index == 1) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => MiniGamesPage(viewerName: viewerName),
        ),
      );
      return;
    }
    if (index == 2) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => ShortsPage(viewerName: viewerName),
        ),
      );
      return;
    }
    if (index == 0) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => ProfilePage(viewerName: viewerName),
        ),
      );
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      child: Container(
        height: 68,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: const BoxDecoration(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            GestureDetector(
              onTap: () => _goTo(context, 0),
              child: _BottomNavIcon(
                icon: Icons.person_rounded,
                selected: currentIndex == 0,
              ),
            ),
            GestureDetector(
              onTap: () => _goTo(context, 1),
              child: _BottomNavIcon(
                icon: Icons.sports_esports_rounded,
                selected: currentIndex == 1,
              ),
            ),
            GestureDetector(
              onTap: () => _goTo(context, 2),
              child: _BottomNavIcon(
                icon: Icons.play_circle_fill_rounded,
                selected: currentIndex == 2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomNavIcon extends StatelessWidget {
  const _BottomNavIcon({required this.icon, required this.selected});

  final IconData icon;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      width: 52,
      height: 46,
      child: Icon(
        icon,
        size: selected ? 35 : 32,
        color: selected
            ? const Color(0xFFFFB2C7)
            : Colors.white.withValues(alpha: 0.76),
      ),
    );
  }
}
