param(
    [ValidateSet('web', 'windows')]
    [string]$Target = 'web'
)

$ErrorActionPreference = 'Stop'

Write-Host 'Installing Flutter dependencies...' -ForegroundColor Cyan
flutter pub get

Write-Host 'Running analyzer...' -ForegroundColor Cyan
flutter analyze --no-fatal-infos

Write-Host 'Running tests...' -ForegroundColor Cyan
flutter test

Write-Host "Building Flutter $Target release..." -ForegroundColor Cyan
if ($Target -eq 'windows') {
    flutter build windows --release
} else {
    flutter build web --release
}

Write-Host 'Build completed successfully.' -ForegroundColor Green
